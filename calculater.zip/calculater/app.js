function insert(num){
    document.getElementById("rz").value=document.getElementById("rz").value+num
}
function equal(){
    var ro=document.getElementById("rz").value;
    if(ro){
        document.getElementById("rz").value = eval(ro)

    }
    
}
function clean(){
    document.getElementById("rz").value =""
}
function back(){
    var bk=document.getElementById("rz").value;
    document.getElementById("rz").value=bk.substring(0,bk.length-1)
}